.model small
.stack 100h
.data
    msg_inicio db "Mueve el mouse. Haz CLIC IZQUIERDO para salir...", 0dh, 0ah, "$"
.code
main proc
    ; Inicializar el segmento de datos
    mov ax, @data
    mov ds, ax
    
    ; Mostrar mensaje inicial en pantalla (Int 21h, AH=09h)
    mov dx, offset msg_inicio
    mov ah, 09h
    int 21h

    ; 1. INICIALIZAR EL MOUSE
    mov ax, 0000h
    int 33h
    cmp ax, 0000h      ; Comprobar si el hardware esta disponible
    je salir           ; Si AX es 0, terminar el programa ya que no hay mouse

    ; 2. MOSTRAR EL PUNTERO EN PANTALLA
    mov ax, 0001h
    int 33h

bucle_lectura:
    ; 3. LEER EL ESTADO DEL MOUSE
    mov ax, 0003h
    int 33h            ; Retorna: BX = botones, CX = X, DX = Y

    ; Verificar si se presiono el boton izquierdo (Bit 0 de BX = 1)
    test bx, 1
    jnz ocultar_y_salir ; Si no es cero (clic), salimos del bucle

    ; Peque�a pausa para no saturar la CPU en el emulador
    mov cx, 00h
    mov dx, 0F000h
    mov ah, 86h
    int 15h

    jmp bucle_lectura

ocultar_y_salir:
    ; 4. OCULTAR EL MOUSE ANTES DE TERMINAR (Buena practica)
    mov ax, 0002h
    int 33h

salir:
    ; Finalizar programa regresando el control al DOS
    mov ah, 4ch
    int 21h
main endp
end main