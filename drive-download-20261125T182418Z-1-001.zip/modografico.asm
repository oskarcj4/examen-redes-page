.model small
.stack 100h
.data
.code
main proc
    ; 1. INICIAR MODO GR�FICO (Modo 13h: 320x200 p�xeles, 256 colores)
    mov ax, 0013h
    int 10h

    ; 2. INICIALIZAR MOUSE
    mov ax, 0000h
    int 33h
    cmp ax, 0000h
    je restaurar_texto   ; Si no hay mouse, salir

    ; 3. MOSTRAR EL PUNTERO EN MODO GR�FICO
    mov ax, 0001h
    int 33h

bucle_dibujo:
    ; 4. LEER ESTADO DEL MOUSE
    mov ax, 0003h
    int 33h            ; BX=botones, CX=X (0-639), DX=Y (0-199)

    ; Condici�n de salida: Clic derecho (Bit 1 de BX) finaliza el programa
    test bx, 2
    jnz terminar_grafico

    ; Condici�n de dibujo: Clic izquierdo (Bit 0 de BX) dibuja un p�xel
    test bx, 1
    jz bucle_dibujo      ; Si no est� presionando, saltar y seguir leyendo

    ; --- PROCESAR COORDENADAS PARA EL MODO 13H ---
    ; CX viene de 0 a 639. Para mapearlo a la pantalla de 320 p�xeles, dividimos entre 2.
    shr cx, 1            ; Desplazamiento a la derecha (Equivale a CX / 2)

    ; --- DIBUJAR P�XEL DIRECTAMENTE EN PANTALLA ---
    ; Como el cursor del mouse tapa el p�xel en el momento exacto,
    ; ocultamos el mouse un instante, pintamos y lo volvemos a mostrar.
    mov ax, 0002h
    int 33h              ; Ocultar mouse

    mov ah, 0Ch          ; Funci�n: Escribir p�xel gr�fico
    mov al, 0Bh          ; Color: Cian claro (puedes cambiarlo del 0 al 255)
    mov bh, 0            ; P�gina de video 0
    ; CX y DX ya tienen las coordenadas correctas para la INT 10h
    int 10h              ; Dibujar p�xel

    mov ax, 0001h
    int 33h              ; Mostrar mouse nuevamente

    jmp bucle_dibujo

terminar_grafico:
    ; Ocultar el mouse antes de alterar el modo de video
    mov ax, 0002h
    int 33h

restaurar_texto:
    ; 5. RESTAURAR MODO TEXTO EST�NDAR (Modo 03h) Al terminar
    mov ax, 0003h
    int 10h

    ; Finalizar programa
    mov ah, 4Ch
    int 21h
main endp
end main